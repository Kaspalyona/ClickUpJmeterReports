/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 155.0, "minX": 0.0, "maxY": 11170.0, "series": [{"data": [[0.0, 155.0], [0.1, 157.0], [0.2, 158.0], [0.3, 158.0], [0.4, 159.0], [0.5, 159.0], [0.6, 159.0], [0.7, 159.0], [0.8, 160.0], [0.9, 160.0], [1.0, 160.0], [1.1, 160.0], [1.2, 160.0], [1.3, 161.0], [1.4, 161.0], [1.5, 161.0], [1.6, 161.0], [1.7, 161.0], [1.8, 161.0], [1.9, 161.0], [2.0, 161.0], [2.1, 161.0], [2.2, 161.0], [2.3, 162.0], [2.4, 162.0], [2.5, 162.0], [2.6, 162.0], [2.7, 162.0], [2.8, 162.0], [2.9, 162.0], [3.0, 162.0], [3.1, 162.0], [3.2, 162.0], [3.3, 162.0], [3.4, 162.0], [3.5, 162.0], [3.6, 163.0], [3.7, 163.0], [3.8, 163.0], [3.9, 163.0], [4.0, 163.0], [4.1, 163.0], [4.2, 163.0], [4.3, 163.0], [4.4, 163.0], [4.5, 163.0], [4.6, 163.0], [4.7, 163.0], [4.8, 163.0], [4.9, 163.0], [5.0, 163.0], [5.1, 163.0], [5.2, 163.0], [5.3, 163.0], [5.4, 163.0], [5.5, 163.0], [5.6, 163.0], [5.7, 163.0], [5.8, 164.0], [5.9, 164.0], [6.0, 164.0], [6.1, 164.0], [6.2, 164.0], [6.3, 164.0], [6.4, 164.0], [6.5, 164.0], [6.6, 164.0], [6.7, 164.0], [6.8, 164.0], [6.9, 164.0], [7.0, 164.0], [7.1, 164.0], [7.2, 164.0], [7.3, 164.0], [7.4, 164.0], [7.5, 164.0], [7.6, 164.0], [7.7, 164.0], [7.8, 164.0], [7.9, 164.0], [8.0, 164.0], [8.1, 164.0], [8.2, 164.0], [8.3, 164.0], [8.4, 165.0], [8.5, 165.0], [8.6, 165.0], [8.7, 165.0], [8.8, 165.0], [8.9, 165.0], [9.0, 165.0], [9.1, 165.0], [9.2, 165.0], [9.3, 165.0], [9.4, 165.0], [9.5, 165.0], [9.6, 165.0], [9.7, 165.0], [9.8, 165.0], [9.9, 165.0], [10.0, 165.0], [10.1, 165.0], [10.2, 165.0], [10.3, 165.0], [10.4, 165.0], [10.5, 165.0], [10.6, 165.0], [10.7, 165.0], [10.8, 165.0], [10.9, 165.0], [11.0, 165.0], [11.1, 165.0], [11.2, 165.0], [11.3, 165.0], [11.4, 165.0], [11.5, 165.0], [11.6, 165.0], [11.7, 166.0], [11.8, 166.0], [11.9, 166.0], [12.0, 166.0], [12.1, 166.0], [12.2, 166.0], [12.3, 166.0], [12.4, 166.0], [12.5, 166.0], [12.6, 166.0], [12.7, 166.0], [12.8, 166.0], [12.9, 166.0], [13.0, 166.0], [13.1, 166.0], [13.2, 166.0], [13.3, 166.0], [13.4, 166.0], [13.5, 166.0], [13.6, 166.0], [13.7, 166.0], [13.8, 166.0], [13.9, 166.0], [14.0, 166.0], [14.1, 166.0], [14.2, 166.0], [14.3, 166.0], [14.4, 166.0], [14.5, 166.0], [14.6, 166.0], [14.7, 166.0], [14.8, 166.0], [14.9, 166.0], [15.0, 166.0], [15.1, 167.0], [15.2, 167.0], [15.3, 167.0], [15.4, 167.0], [15.5, 167.0], [15.6, 167.0], [15.7, 167.0], [15.8, 167.0], [15.9, 167.0], [16.0, 167.0], [16.1, 167.0], [16.2, 167.0], [16.3, 167.0], [16.4, 167.0], [16.5, 167.0], [16.6, 167.0], [16.7, 167.0], [16.8, 167.0], [16.9, 167.0], [17.0, 167.0], [17.1, 167.0], [17.2, 167.0], [17.3, 167.0], [17.4, 167.0], [17.5, 167.0], [17.6, 167.0], [17.7, 167.0], [17.8, 167.0], [17.9, 167.0], [18.0, 167.0], [18.1, 167.0], [18.2, 167.0], [18.3, 167.0], [18.4, 167.0], [18.5, 167.0], [18.6, 167.0], [18.7, 167.0], [18.8, 167.0], [18.9, 167.0], [19.0, 168.0], [19.1, 168.0], [19.2, 168.0], [19.3, 168.0], [19.4, 168.0], [19.5, 168.0], [19.6, 168.0], [19.7, 168.0], [19.8, 168.0], [19.9, 168.0], [20.0, 168.0], [20.1, 168.0], [20.2, 168.0], [20.3, 168.0], [20.4, 168.0], [20.5, 168.0], [20.6, 168.0], [20.7, 168.0], [20.8, 168.0], [20.9, 168.0], [21.0, 168.0], [21.1, 168.0], [21.2, 168.0], [21.3, 168.0], [21.4, 168.0], [21.5, 168.0], [21.6, 168.0], [21.7, 168.0], [21.8, 168.0], [21.9, 168.0], [22.0, 168.0], [22.1, 168.0], [22.2, 168.0], [22.3, 168.0], [22.4, 168.0], [22.5, 168.0], [22.6, 168.0], [22.7, 168.0], [22.8, 168.0], [22.9, 168.0], [23.0, 168.0], [23.1, 168.0], [23.2, 168.0], [23.3, 168.0], [23.4, 168.0], [23.5, 168.0], [23.6, 168.0], [23.7, 169.0], [23.8, 169.0], [23.9, 169.0], [24.0, 169.0], [24.1, 169.0], [24.2, 169.0], [24.3, 169.0], [24.4, 169.0], [24.5, 169.0], [24.6, 169.0], [24.7, 169.0], [24.8, 169.0], [24.9, 169.0], [25.0, 169.0], [25.1, 169.0], [25.2, 169.0], [25.3, 169.0], [25.4, 169.0], [25.5, 169.0], [25.6, 169.0], [25.7, 169.0], [25.8, 169.0], [25.9, 169.0], [26.0, 169.0], [26.1, 169.0], [26.2, 169.0], [26.3, 169.0], [26.4, 169.0], [26.5, 169.0], [26.6, 169.0], [26.7, 169.0], [26.8, 169.0], [26.9, 169.0], [27.0, 169.0], [27.1, 169.0], [27.2, 169.0], [27.3, 169.0], [27.4, 169.0], [27.5, 169.0], [27.6, 169.0], [27.7, 169.0], [27.8, 169.0], [27.9, 169.0], [28.0, 169.0], [28.1, 169.0], [28.2, 170.0], [28.3, 170.0], [28.4, 170.0], [28.5, 170.0], [28.6, 170.0], [28.7, 170.0], [28.8, 170.0], [28.9, 170.0], [29.0, 170.0], [29.1, 170.0], [29.2, 170.0], [29.3, 170.0], [29.4, 170.0], [29.5, 170.0], [29.6, 170.0], [29.7, 170.0], [29.8, 170.0], [29.9, 170.0], [30.0, 170.0], [30.1, 170.0], [30.2, 170.0], [30.3, 170.0], [30.4, 170.0], [30.5, 170.0], [30.6, 170.0], [30.7, 170.0], [30.8, 170.0], [30.9, 170.0], [31.0, 170.0], [31.1, 170.0], [31.2, 170.0], [31.3, 170.0], [31.4, 170.0], [31.5, 170.0], [31.6, 170.0], [31.7, 170.0], [31.8, 170.0], [31.9, 170.0], [32.0, 170.0], [32.1, 170.0], [32.2, 170.0], [32.3, 170.0], [32.4, 170.0], [32.5, 170.0], [32.6, 170.0], [32.7, 170.0], [32.8, 170.0], [32.9, 171.0], [33.0, 171.0], [33.1, 171.0], [33.2, 171.0], [33.3, 171.0], [33.4, 171.0], [33.5, 171.0], [33.6, 171.0], [33.7, 171.0], [33.8, 171.0], [33.9, 171.0], [34.0, 171.0], [34.1, 171.0], [34.2, 171.0], [34.3, 171.0], [34.4, 171.0], [34.5, 171.0], [34.6, 171.0], [34.7, 171.0], [34.8, 171.0], [34.9, 171.0], [35.0, 171.0], [35.1, 171.0], [35.2, 171.0], [35.3, 171.0], [35.4, 171.0], [35.5, 171.0], [35.6, 171.0], [35.7, 171.0], [35.8, 171.0], [35.9, 171.0], [36.0, 171.0], [36.1, 171.0], [36.2, 171.0], [36.3, 171.0], [36.4, 171.0], [36.5, 171.0], [36.6, 171.0], [36.7, 171.0], [36.8, 171.0], [36.9, 171.0], [37.0, 171.0], [37.1, 171.0], [37.2, 171.0], [37.3, 171.0], [37.4, 172.0], [37.5, 172.0], [37.6, 172.0], [37.7, 172.0], [37.8, 172.0], [37.9, 172.0], [38.0, 172.0], [38.1, 172.0], [38.2, 172.0], [38.3, 172.0], [38.4, 172.0], [38.5, 172.0], [38.6, 172.0], [38.7, 172.0], [38.8, 172.0], [38.9, 172.0], [39.0, 172.0], [39.1, 172.0], [39.2, 172.0], [39.3, 172.0], [39.4, 172.0], [39.5, 172.0], [39.6, 172.0], [39.7, 172.0], [39.8, 172.0], [39.9, 172.0], [40.0, 172.0], [40.1, 172.0], [40.2, 172.0], [40.3, 172.0], [40.4, 172.0], [40.5, 172.0], [40.6, 172.0], [40.7, 172.0], [40.8, 172.0], [40.9, 172.0], [41.0, 172.0], [41.1, 172.0], [41.2, 172.0], [41.3, 172.0], [41.4, 172.0], [41.5, 172.0], [41.6, 172.0], [41.7, 172.0], [41.8, 172.0], [41.9, 172.0], [42.0, 172.0], [42.1, 172.0], [42.2, 172.0], [42.3, 173.0], [42.4, 173.0], [42.5, 173.0], [42.6, 173.0], [42.7, 173.0], [42.8, 173.0], [42.9, 173.0], [43.0, 173.0], [43.1, 173.0], [43.2, 173.0], [43.3, 173.0], [43.4, 173.0], [43.5, 173.0], [43.6, 173.0], [43.7, 173.0], [43.8, 173.0], [43.9, 173.0], [44.0, 173.0], [44.1, 173.0], [44.2, 173.0], [44.3, 173.0], [44.4, 173.0], [44.5, 173.0], [44.6, 173.0], [44.7, 173.0], [44.8, 173.0], [44.9, 173.0], [45.0, 173.0], [45.1, 173.0], [45.2, 173.0], [45.3, 173.0], [45.4, 173.0], [45.5, 173.0], [45.6, 173.0], [45.7, 173.0], [45.8, 173.0], [45.9, 173.0], [46.0, 173.0], [46.1, 173.0], [46.2, 173.0], [46.3, 173.0], [46.4, 174.0], [46.5, 174.0], [46.6, 174.0], [46.7, 174.0], [46.8, 174.0], [46.9, 174.0], [47.0, 174.0], [47.1, 174.0], [47.2, 174.0], [47.3, 174.0], [47.4, 174.0], [47.5, 174.0], [47.6, 174.0], [47.7, 174.0], [47.8, 174.0], [47.9, 174.0], [48.0, 174.0], [48.1, 174.0], [48.2, 174.0], [48.3, 174.0], [48.4, 174.0], [48.5, 174.0], [48.6, 174.0], [48.7, 174.0], [48.8, 174.0], [48.9, 174.0], [49.0, 174.0], [49.1, 174.0], [49.2, 174.0], [49.3, 174.0], [49.4, 174.0], [49.5, 174.0], [49.6, 174.0], [49.7, 174.0], [49.8, 174.0], [49.9, 174.0], [50.0, 174.0], [50.1, 174.0], [50.2, 174.0], [50.3, 175.0], [50.4, 175.0], [50.5, 175.0], [50.6, 175.0], [50.7, 175.0], [50.8, 175.0], [50.9, 175.0], [51.0, 175.0], [51.1, 175.0], [51.2, 175.0], [51.3, 175.0], [51.4, 175.0], [51.5, 175.0], [51.6, 175.0], [51.7, 175.0], [51.8, 175.0], [51.9, 175.0], [52.0, 175.0], [52.1, 175.0], [52.2, 175.0], [52.3, 175.0], [52.4, 175.0], [52.5, 175.0], [52.6, 175.0], [52.7, 175.0], [52.8, 175.0], [52.9, 175.0], [53.0, 175.0], [53.1, 175.0], [53.2, 175.0], [53.3, 175.0], [53.4, 175.0], [53.5, 175.0], [53.6, 175.0], [53.7, 175.0], [53.8, 175.0], [53.9, 175.0], [54.0, 176.0], [54.1, 176.0], [54.2, 176.0], [54.3, 176.0], [54.4, 176.0], [54.5, 176.0], [54.6, 176.0], [54.7, 176.0], [54.8, 176.0], [54.9, 176.0], [55.0, 176.0], [55.1, 176.0], [55.2, 176.0], [55.3, 176.0], [55.4, 176.0], [55.5, 176.0], [55.6, 176.0], [55.7, 176.0], [55.8, 176.0], [55.9, 176.0], [56.0, 176.0], [56.1, 176.0], [56.2, 176.0], [56.3, 176.0], [56.4, 176.0], [56.5, 176.0], [56.6, 176.0], [56.7, 176.0], [56.8, 176.0], [56.9, 176.0], [57.0, 176.0], [57.1, 177.0], [57.2, 177.0], [57.3, 177.0], [57.4, 177.0], [57.5, 177.0], [57.6, 177.0], [57.7, 177.0], [57.8, 177.0], [57.9, 177.0], [58.0, 177.0], [58.1, 177.0], [58.2, 177.0], [58.3, 177.0], [58.4, 177.0], [58.5, 177.0], [58.6, 177.0], [58.7, 177.0], [58.8, 177.0], [58.9, 177.0], [59.0, 177.0], [59.1, 177.0], [59.2, 177.0], [59.3, 177.0], [59.4, 177.0], [59.5, 177.0], [59.6, 177.0], [59.7, 177.0], [59.8, 177.0], [59.9, 177.0], [60.0, 177.0], [60.1, 177.0], [60.2, 178.0], [60.3, 178.0], [60.4, 178.0], [60.5, 178.0], [60.6, 178.0], [60.7, 178.0], [60.8, 178.0], [60.9, 178.0], [61.0, 178.0], [61.1, 178.0], [61.2, 178.0], [61.3, 178.0], [61.4, 178.0], [61.5, 178.0], [61.6, 178.0], [61.7, 178.0], [61.8, 178.0], [61.9, 178.0], [62.0, 178.0], [62.1, 178.0], [62.2, 178.0], [62.3, 178.0], [62.4, 178.0], [62.5, 178.0], [62.6, 178.0], [62.7, 178.0], [62.8, 179.0], [62.9, 179.0], [63.0, 179.0], [63.1, 179.0], [63.2, 179.0], [63.3, 179.0], [63.4, 179.0], [63.5, 179.0], [63.6, 179.0], [63.7, 179.0], [63.8, 179.0], [63.9, 179.0], [64.0, 179.0], [64.1, 179.0], [64.2, 179.0], [64.3, 179.0], [64.4, 179.0], [64.5, 179.0], [64.6, 179.0], [64.7, 179.0], [64.8, 179.0], [64.9, 179.0], [65.0, 179.0], [65.1, 179.0], [65.2, 179.0], [65.3, 179.0], [65.4, 179.0], [65.5, 179.0], [65.6, 179.0], [65.7, 180.0], [65.8, 180.0], [65.9, 180.0], [66.0, 180.0], [66.1, 180.0], [66.2, 180.0], [66.3, 180.0], [66.4, 180.0], [66.5, 180.0], [66.6, 180.0], [66.7, 180.0], [66.8, 180.0], [66.9, 180.0], [67.0, 180.0], [67.1, 180.0], [67.2, 180.0], [67.3, 180.0], [67.4, 180.0], [67.5, 180.0], [67.6, 180.0], [67.7, 181.0], [67.8, 181.0], [67.9, 181.0], [68.0, 181.0], [68.1, 181.0], [68.2, 181.0], [68.3, 181.0], [68.4, 181.0], [68.5, 181.0], [68.6, 181.0], [68.7, 181.0], [68.8, 181.0], [68.9, 181.0], [69.0, 181.0], [69.1, 181.0], [69.2, 181.0], [69.3, 181.0], [69.4, 181.0], [69.5, 181.0], [69.6, 181.0], [69.7, 182.0], [69.8, 182.0], [69.9, 182.0], [70.0, 182.0], [70.1, 182.0], [70.2, 182.0], [70.3, 182.0], [70.4, 182.0], [70.5, 182.0], [70.6, 182.0], [70.7, 182.0], [70.8, 182.0], [70.9, 182.0], [71.0, 182.0], [71.1, 182.0], [71.2, 182.0], [71.3, 182.0], [71.4, 182.0], [71.5, 182.0], [71.6, 182.0], [71.7, 183.0], [71.8, 183.0], [71.9, 183.0], [72.0, 183.0], [72.1, 183.0], [72.2, 183.0], [72.3, 183.0], [72.4, 183.0], [72.5, 183.0], [72.6, 183.0], [72.7, 183.0], [72.8, 183.0], [72.9, 183.0], [73.0, 183.0], [73.1, 183.0], [73.2, 183.0], [73.3, 183.0], [73.4, 184.0], [73.5, 184.0], [73.6, 184.0], [73.7, 184.0], [73.8, 184.0], [73.9, 184.0], [74.0, 184.0], [74.1, 184.0], [74.2, 184.0], [74.3, 184.0], [74.4, 184.0], [74.5, 184.0], [74.6, 185.0], [74.7, 185.0], [74.8, 185.0], [74.9, 185.0], [75.0, 185.0], [75.1, 185.0], [75.2, 185.0], [75.3, 185.0], [75.4, 185.0], [75.5, 185.0], [75.6, 185.0], [75.7, 185.0], [75.8, 185.0], [75.9, 186.0], [76.0, 186.0], [76.1, 186.0], [76.2, 186.0], [76.3, 186.0], [76.4, 186.0], [76.5, 186.0], [76.6, 186.0], [76.7, 186.0], [76.8, 186.0], [76.9, 187.0], [77.0, 187.0], [77.1, 187.0], [77.2, 187.0], [77.3, 187.0], [77.4, 187.0], [77.5, 187.0], [77.6, 187.0], [77.7, 187.0], [77.8, 187.0], [77.9, 187.0], [78.0, 188.0], [78.1, 188.0], [78.2, 188.0], [78.3, 188.0], [78.4, 188.0], [78.5, 188.0], [78.6, 188.0], [78.7, 188.0], [78.8, 189.0], [78.9, 189.0], [79.0, 189.0], [79.1, 189.0], [79.2, 189.0], [79.3, 189.0], [79.4, 189.0], [79.5, 189.0], [79.6, 190.0], [79.7, 190.0], [79.8, 190.0], [79.9, 190.0], [80.0, 190.0], [80.1, 190.0], [80.2, 190.0], [80.3, 190.0], [80.4, 190.0], [80.5, 191.0], [80.6, 191.0], [80.7, 191.0], [80.8, 191.0], [80.9, 191.0], [81.0, 191.0], [81.1, 191.0], [81.2, 191.0], [81.3, 191.0], [81.4, 192.0], [81.5, 192.0], [81.6, 192.0], [81.7, 192.0], [81.8, 192.0], [81.9, 192.0], [82.0, 193.0], [82.1, 193.0], [82.2, 193.0], [82.3, 193.0], [82.4, 193.0], [82.5, 194.0], [82.6, 194.0], [82.7, 194.0], [82.8, 194.0], [82.9, 194.0], [83.0, 194.0], [83.1, 195.0], [83.2, 195.0], [83.3, 195.0], [83.4, 195.0], [83.5, 196.0], [83.6, 196.0], [83.7, 196.0], [83.8, 196.0], [83.9, 196.0], [84.0, 197.0], [84.1, 197.0], [84.2, 197.0], [84.3, 197.0], [84.4, 197.0], [84.5, 198.0], [84.6, 198.0], [84.7, 198.0], [84.8, 198.0], [84.9, 199.0], [85.0, 199.0], [85.1, 199.0], [85.2, 200.0], [85.3, 200.0], [85.4, 201.0], [85.5, 201.0], [85.6, 201.0], [85.7, 201.0], [85.8, 202.0], [85.9, 202.0], [86.0, 202.0], [86.1, 203.0], [86.2, 203.0], [86.3, 203.0], [86.4, 203.0], [86.5, 203.0], [86.6, 204.0], [86.7, 204.0], [86.8, 204.0], [86.9, 205.0], [87.0, 205.0], [87.1, 206.0], [87.2, 206.0], [87.3, 206.0], [87.4, 207.0], [87.5, 208.0], [87.6, 209.0], [87.7, 210.0], [87.8, 211.0], [87.9, 211.0], [88.0, 212.0], [88.1, 213.0], [88.2, 215.0], [88.3, 217.0], [88.4, 221.0], [88.5, 224.0], [88.6, 225.0], [88.7, 229.0], [88.8, 234.0], [88.9, 240.0], [89.0, 241.0], [89.1, 258.0], [89.2, 304.0], [89.3, 403.0], [89.4, 432.0], [89.5, 445.0], [89.6, 465.0], [89.7, 478.0], [89.8, 585.0], [89.9, 791.0], [90.0, 926.0], [90.1, 980.0], [90.2, 1077.0], [90.3, 1161.0], [90.4, 1163.0], [90.5, 1164.0], [90.6, 1164.0], [90.7, 1165.0], [90.8, 1165.0], [90.9, 1166.0], [91.0, 1166.0], [91.1, 1167.0], [91.2, 1167.0], [91.3, 1167.0], [91.4, 1168.0], [91.5, 1168.0], [91.6, 1169.0], [91.7, 1169.0], [91.8, 1169.0], [91.9, 1170.0], [92.0, 1170.0], [92.1, 1170.0], [92.2, 1170.0], [92.3, 1171.0], [92.4, 1171.0], [92.5, 1172.0], [92.6, 1172.0], [92.7, 1173.0], [92.8, 1174.0], [92.9, 1174.0], [93.0, 1174.0], [93.1, 1175.0], [93.2, 1175.0], [93.3, 1176.0], [93.4, 1176.0], [93.5, 1177.0], [93.6, 1177.0], [93.7, 1179.0], [93.8, 1180.0], [93.9, 1180.0], [94.0, 1182.0], [94.1, 1183.0], [94.2, 1184.0], [94.3, 1189.0], [94.4, 1192.0], [94.5, 1194.0], [94.6, 1206.0], [94.7, 1231.0], [94.8, 1844.0], [94.9, 2162.0], [95.0, 2164.0], [95.1, 2164.0], [95.2, 2165.0], [95.3, 2166.0], [95.4, 2167.0], [95.5, 2168.0], [95.6, 2168.0], [95.7, 2169.0], [95.8, 2169.0], [95.9, 2170.0], [96.0, 2170.0], [96.1, 2171.0], [96.2, 2171.0], [96.3, 2172.0], [96.4, 2173.0], [96.5, 2173.0], [96.6, 2174.0], [96.7, 2175.0], [96.8, 2176.0], [96.9, 2177.0], [97.0, 2177.0], [97.1, 2178.0], [97.2, 2179.0], [97.3, 2180.0], [97.4, 2182.0], [97.5, 2183.0], [97.6, 2185.0], [97.7, 2187.0], [97.8, 2189.0], [97.9, 2191.0], [98.0, 2195.0], [98.1, 2197.0], [98.2, 2209.0], [98.3, 3160.0], [98.4, 3165.0], [98.5, 3167.0], [98.6, 3170.0], [98.7, 3173.0], [98.8, 3174.0], [98.9, 3176.0], [99.0, 3179.0], [99.1, 3186.0], [99.2, 3203.0], [99.3, 3247.0], [99.4, 4167.0], [99.5, 4173.0], [99.6, 4176.0], [99.7, 4181.0], [99.8, 4203.0], [99.9, 5204.0], [100.0, 11170.0]], "isOverall": false, "label": "Get User", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 100.0, "maxY": 4708.0, "series": [{"data": [[600.0, 1.0], [700.0, 5.0], [11100.0, 1.0], [800.0, 3.0], [900.0, 9.0], [1000.0, 4.0], [1100.0, 240.0], [1200.0, 9.0], [1300.0, 2.0], [1400.0, 2.0], [100.0, 4708.0], [1800.0, 2.0], [2100.0, 182.0], [2200.0, 7.0], [2900.0, 3.0], [3100.0, 50.0], [200.0, 226.0], [3200.0, 7.0], [3500.0, 1.0], [4100.0, 24.0], [4200.0, 5.0], [300.0, 6.0], [5100.0, 2.0], [5200.0, 1.0], [400.0, 24.0], [7100.0, 4.0], [500.0, 4.0]], "isOverall": false, "label": "Get User", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 11100.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 3.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 5432.0, "series": [{"data": [[0.0, 97.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 3.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 5432.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 20.0, "minX": 1.72104324E12, "maxY": 54.816402225427666, "series": [{"data": [[1.7210433E12, 54.816402225427666], [1.72104324E12, 20.0]], "isOverall": false, "label": "jp@gc - Навантаження 20 users/sec протягом 20 sec, потім ramp up навантаження 100 users/sec на 30 sec ", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7210433E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 172.0, "minX": 1.0, "maxY": 11170.0, "series": [{"data": [[2.0, 4173.0], [3.0, 4167.0], [4.0, 919.0], [5.0, 757.3333333333334], [6.0, 1057.7777777777776], [7.0, 624.0909090909091], [8.0, 569.3], [9.0, 837.75], [10.0, 599.5714285714287], [11.0, 1059.0], [12.0, 631.8461538461538], [13.0, 459.1428571428571], [14.0, 313.5238095238095], [15.0, 309.21739130434776], [16.0, 262.77272727272725], [17.0, 358.0], [18.0, 373.33333333333337], [19.0, 638.8000000000001], [20.0, 277.87994448299776], [21.0, 446.38888888888897], [22.0, 505.6190476190476], [23.0, 670.2727272727273], [24.0, 412.76], [25.0, 348.2142857142857], [26.0, 405.2307692307693], [27.0, 394.8064516129032], [28.0, 294.3125], [29.0, 328.81250000000006], [30.0, 334.72], [31.0, 343.53846153846155], [32.0, 411.4848484848485], [33.0, 376.61764705882354], [34.0, 295.5609756097561], [35.0, 266.24999999999994], [36.0, 309.4509803921568], [37.0, 358.86538461538476], [38.0, 286.66666666666663], [39.0, 224.15151515151516], [40.0, 205.41269841269843], [41.0, 203.62500000000006], [42.0, 316.73214285714283], [43.0, 193.2833333333333], [44.0, 229.86666666666667], [45.0, 298.5090909090909], [46.0, 213.8913043478261], [47.0, 227.13157894736844], [48.0, 290.3333333333333], [49.0, 424.5744680851064], [50.0, 373.49090909090916], [51.0, 327.56862745098033], [52.0, 326.14285714285705], [53.0, 318.53061224489795], [54.0, 362.1428571428573], [55.0, 242.87500000000003], [56.0, 373.33333333333337], [57.0, 400.35], [58.0, 466.8378378378378], [59.0, 449.51162790697686], [60.0, 433.48837209302326], [61.0, 559.1739130434784], [62.0, 345.5777777777778], [63.0, 459.78846153846155], [64.0, 301.59574468085117], [65.0, 329.6000000000001], [66.0, 390.82926829268297], [67.0, 437.9333333333335], [68.0, 490.61224489795916], [69.0, 379.7727272727273], [70.0, 375.1730769230769], [71.0, 452.16], [72.0, 376.4745762711864], [73.0, 388.3157894736843], [74.0, 324.90163934426226], [75.0, 286.9433962264151], [76.0, 513.7555555555555], [77.0, 357.6521739130434], [78.0, 557.3728813559323], [79.0, 303.2586206896551], [80.0, 331.3999999999999], [81.0, 306.0], [82.0, 569.9285714285717], [83.0, 416.27272727272725], [84.0, 302.45901639344254], [85.0, 282.5272727272729], [86.0, 492.63076923076915], [87.0, 308.89705882352956], [88.0, 413.5254237288135], [89.0, 548.8548387096774], [90.0, 289.0793650793652], [91.0, 376.0869565217391], [92.0, 372.49999999999994], [93.0, 318.9811320754717], [94.0, 579.9830508474579], [95.0, 433.69354838709677], [96.0, 555.2857142857143], [97.0, 446.15625], [98.0, 663.2307692307693], [99.0, 475.2258064516129], [100.0, 172.0], [1.0, 11170.0]], "isOverall": false, "label": "Get User", "isController": false}, {"data": [[50.5430224150397, 358.8761749819223]], "isOverall": false, "label": "Get User-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 2206.75, "minX": 1.72104324E12, "maxY": 68742.0, "series": [{"data": [[1.7210433E12, 68742.0], [1.72104324E12, 9851.066666666668]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.7210433E12, 15772.25], [1.72104324E12, 2206.75]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7210433E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 213.20029455081004, "minX": 1.72104324E12, "maxY": 379.2581908098088, "series": [{"data": [[1.7210433E12, 379.2581908098088], [1.72104324E12, 213.20029455081004]], "isOverall": false, "label": "Get User", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7210433E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 213.18556701030934, "minX": 1.72104324E12, "maxY": 379.2480939624972, "series": [{"data": [[1.7210433E12, 379.2480939624972], [1.72104324E12, 213.18556701030934]], "isOverall": false, "label": "Get User", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7210433E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 145.16936671575834, "minX": 1.72104324E12, "maxY": 309.65588295899437, "series": [{"data": [[1.7210433E12, 309.65588295899437], [1.72104324E12, 145.16936671575834]], "isOverall": false, "label": "Get User", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7210433E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 176.0, "minX": 1.72104324E12, "maxY": 560.0, "series": [{"data": [[1.72104324E12, 560.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.72104324E12, 176.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.72104324E12, 458.8]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.72104324E12, 559.91]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.72104324E12, 201.5]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.72104324E12, 477.6499999999999]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.72104324E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 169.5, "minX": 1.0, "maxY": 7671.5, "series": [{"data": [[20.0, 458.0], [108.0, 193.5]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[38.0, 172.0], [50.0, 172.0], [51.0, 174.0], [54.0, 171.0], [57.0, 171.5], [59.0, 170.0], [58.0, 172.0], [60.0, 170.5], [63.0, 171.0], [66.0, 170.0], [65.0, 173.0], [70.0, 172.0], [73.0, 172.0], [76.0, 170.0], [78.0, 170.0], [5.0, 4169.0], [84.0, 171.0], [91.0, 172.0], [90.0, 174.0], [95.0, 171.0], [108.0, 170.0], [110.0, 172.5], [112.0, 175.0], [118.0, 171.0], [135.0, 178.0], [143.0, 171.0], [139.0, 173.0], [159.0, 176.0], [158.0, 174.0], [163.0, 173.0], [161.0, 180.0], [174.0, 179.0], [188.0, 179.0], [193.0, 177.0], [196.0, 178.0], [197.0, 173.0], [207.0, 178.0], [208.0, 173.0], [214.0, 182.0], [16.0, 1668.0], [1.0, 7671.5], [20.0, 169.5], [22.0, 3164.0], [23.0, 170.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 214.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 169.5, "minX": 1.0, "maxY": 7671.5, "series": [{"data": [[20.0, 458.0], [108.0, 193.5]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[38.0, 172.0], [50.0, 172.0], [51.0, 174.0], [54.0, 171.0], [57.0, 171.5], [59.0, 170.0], [58.0, 172.0], [60.0, 170.5], [63.0, 171.0], [66.0, 170.0], [65.0, 173.0], [70.0, 172.0], [73.0, 172.0], [76.0, 170.0], [78.0, 170.0], [5.0, 4169.0], [84.0, 171.0], [91.0, 172.0], [90.0, 174.0], [95.0, 171.0], [108.0, 170.0], [110.0, 172.5], [112.0, 175.0], [118.0, 171.0], [135.0, 178.0], [143.0, 171.0], [139.0, 173.0], [159.0, 176.0], [158.0, 174.0], [163.0, 173.0], [161.0, 180.0], [174.0, 179.0], [188.0, 179.0], [193.0, 177.0], [196.0, 178.0], [197.0, 173.0], [207.0, 178.0], [208.0, 173.0], [214.0, 182.0], [16.0, 1668.0], [1.0, 7671.5], [20.0, 169.5], [22.0, 3164.0], [23.0, 170.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 214.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 11.65, "minX": 1.72104324E12, "maxY": 80.55, "series": [{"data": [[1.7210433E12, 80.55], [1.72104324E12, 11.65]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7210433E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 1.6666666666666667, "minX": 1.72104324E12, "maxY": 80.88333333333334, "series": [{"data": [[1.72104324E12, 1.6666666666666667]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.7210433E12, 80.88333333333334], [1.72104324E12, 9.65]], "isOverall": false, "label": "429", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.7210433E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 1.6666666666666667, "minX": 1.72104324E12, "maxY": 80.88333333333334, "series": [{"data": [[1.72104324E12, 1.6666666666666667]], "isOverall": false, "label": "Get User-success", "isController": false}, {"data": [[1.7210433E12, 80.88333333333334], [1.72104324E12, 9.65]], "isOverall": false, "label": "Get User-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7210433E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 1.6666666666666667, "minX": 1.72104324E12, "maxY": 80.88333333333334, "series": [{"data": [[1.72104324E12, 1.6666666666666667]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.7210433E12, 80.88333333333334], [1.72104324E12, 9.65]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.7210433E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 10800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

